
class AddList{
  final String todo;

  AddList({
    required this.todo,

  });
}

