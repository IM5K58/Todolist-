import 'package:flutter/material.dart';
import "package:flutter_feather_icons/flutter_feather_icons.dart";
import 'package:flutter_app/UIs/main_appbar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0XFFFFF3D2),
      appBar: MainAppBar(),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 30,vertical: 40),
        child: IconButton(icon: Icon(FeatherIcons.plus,
        color:Colors.black,
        ),onPressed: (){
          showDialog(
          context: context, 
          builder: (context){
            return AlertDialog(
              title: Text('일정 추가'),
              actions: [
                TextField(
                  decoration: InputDecoration(hintText: '일정추가'),
                ),
                Center(
                  child: ElevatedButton(
                    onPressed: (){},
                    child: Text('추가하기'),
                  ),
                )
              ],
            );
          }
        );},
        
        )
      ),
    );
  }
}