import 'package:flutter/material.dart';
import "package:flutter_feather_icons/flutter_feather_icons.dart";

class MainAppBar extends StatelessWidget implements PreferredSizeWidget {
  final double header_height = 60;
  const MainAppBar({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      centerTitle: true,
      elevation: 2,
      backgroundColor: Color(0XFFFFF3D2),
      title: Text('홈', //글꼴은 마루부리로 간다
        style: TextStyle(
          fontWeight: FontWeight.w300,
          fontSize: 32,
          color: Colors.black
        ),
      ),
      leading: IconButton(icon: Icon(FeatherIcons.menu,color:Colors.black),
      onPressed: (){print('menu opened.');},
    ),

      actions: [
        IconButton(icon: Icon(FeatherIcons.alertCircle,
        color:Colors.black),
        onPressed: (){print('alerm');},),

        IconButton(icon: Icon(FeatherIcons.settings,color:Colors.black
        ),onPressed: (){},),

      ],

    );
  }
}